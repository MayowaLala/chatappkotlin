package performance.com.ng.chat

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth


class Login : AppCompatActivity() {


    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnSignUp: Button
     private lateinit var mAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        mAuth = FirebaseAuth.getInstance()
        editEmail = findViewById(R.id.edit_email) as EditText
        editPassword = findViewById(R.id.edit_password) as EditText
        btnLogin = findViewById(R.id.btn_login) as Button
        btnSignUp = findViewById(R.id.btn_signup) as Button




        btnLogin.setOnClickListener {
            if ( editEmail.text.toString().isEmpty()
                || editPassword.text.toString().isEmpty())
            { Toast.makeText(this, "ensure all fields are filled correctly", Toast.LENGTH_SHORT).show()
            } else {

                val email = editEmail.text.toString()
                val password = editPassword.text.toString()

                login(email, password)
            }


        }

        btnSignUp.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))

        }


    }

    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    startActivity(Intent(this@Login, MainActivity::class.java))
                    finish()
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText( this@Login, "User does not exist", Toast.LENGTH_SHORT).show()
                }
            }
    }
}